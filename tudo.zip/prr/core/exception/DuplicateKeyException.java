package prr.core.exception;

public class DuplicateKeyException extends Exception{
    
    public DuplicateKeyException(){
        super();
    }
}
