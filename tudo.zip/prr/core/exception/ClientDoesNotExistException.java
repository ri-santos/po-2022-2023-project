package prr.core.exception;

public class ClientDoesNotExistException extends Exception{

    public ClientDoesNotExistException(){
        super();
    }
}
