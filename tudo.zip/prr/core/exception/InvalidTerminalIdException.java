package prr.core.exception;

public class InvalidTerminalIdException extends Exception {

    public InvalidTerminalIdException(){
        super();
    }
}
